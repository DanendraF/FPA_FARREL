package Composition;

public class Composition {
    public static void main(String[] args) {
        Seragam s = new Seragam();

        System.out.println(s.seragamToString());
    }
}
