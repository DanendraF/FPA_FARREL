package Hewan;

class Harimau extends Mamalia {
    private int cacahBelang;
    
    @Override
    public String bersuara() {
        return ("Auuuuughmmrrr...");
    }
}