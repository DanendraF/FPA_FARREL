package Hewan;

class Anjing extends Mamalia {
    private int cacahKumis;
    
    @Override
    public String bersuara() {
        return ("guk guk...");
    }
}