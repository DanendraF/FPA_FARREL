package Hewan;


class Gajah extends Mamalia {
    private int cacahGading;

    @Override
    public String bersuara() {
        return ("Brrruuummmmphh!");
    }
}
