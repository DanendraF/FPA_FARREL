package Hewan;

class Mamalia {
    protected int cacahKaki;

    public String bersuara() {
        return ("bersuara");
    }
}
