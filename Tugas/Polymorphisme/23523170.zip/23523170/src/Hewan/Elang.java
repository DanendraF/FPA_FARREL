package Hewan;

class Elang extends Mamalia {
    private int cacahCakar;

    @Override
    public String bersuara() {
        return ("Skreeeeeeew");
    }
}
