package Hewan;

class Kucing extends Mamalia {
    private int cacahKumis;
    
    @Override
    public String bersuara() {
        return ("meong...meong...meong....");
    }
}
