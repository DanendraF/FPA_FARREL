package satuB;

public class Perhitungan {
    int z;

    public void tambah(int c, int d) {
        int e = c + d;
        System.out.println("Hasil penjumlahan = " + e);
    }

    public void kurang(int c, int d) {
        int e = c - d;
        System.out.println("Hasil pengurangan = " + e);
    }
}
