package dua;

public class SiInduk {
    int nilai = 75;

    SiInduk(int nilai) {
        this.nilai = nilai;
    } 

    public void getNilai() {
        System.out.println("Nilai adalah : " +nilai);
    }
}
