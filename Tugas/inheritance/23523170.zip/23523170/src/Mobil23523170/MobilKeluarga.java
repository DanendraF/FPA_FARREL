package Mobil23523170;

public class MobilKeluarga extends Humvee {
    private String merk;
    private String noMesin;
    private int kecepatanMaksimum;

    public void membunyikanKlakson() {
        System.out.println("Mobil keluarga membunyikan klakson");
    }
    public void menampilkanHiburan() {
        System.out.println("Menampilkan hiburan");
    }

}
