package Mobil23523170;

public class Humvee {
    String merk;
    String noMesin;
    String jenisAltileri;

    public void mengerem(){
        System.out.println("Mengrem");
    }
    public void berjalan (){
        System.out.println("Berjalan");
    }
    public void menembakMisil(){
        System.out.println("Menembak misil");
    }
    public void menabrakRintangan (){
        System.out.println("Menabrak rintangan");
    }
}
