package Mobil23523170;

public class MobilOffroad extends Humvee{
    private String merk;
    private String noMesin;
    private int kecepatanMaksimum;

    public void membunyikanKlakson() {
        System.out.println("Klakson: bell... bell...");
    }
    public void melewatiRintanganAlam() {
        System.out.println("Melewati rintangan alam..");      
    }
}
