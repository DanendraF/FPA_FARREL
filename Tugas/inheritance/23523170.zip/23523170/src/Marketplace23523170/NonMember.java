package Marketplace23523170;

public class NonMember extends Transaksi {
    public double Tunai() {
        return harga;
    }

    public double Kredit() {
        return harga;
    }
}

