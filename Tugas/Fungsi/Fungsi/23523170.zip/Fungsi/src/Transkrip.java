public class Transkrip {
    String NIM;
    String Nama;
    int Semester;
    int SKS;
    double IPK;

    public Transkrip(String Ni, String Na, int Sem, int SK, double I) {
        this.NIM = Ni;
        this.Nama = Na;
        this.Semester = Sem;
        this.SKS = SK;
        this.IPK = I;
    }
}

