package Polymorph;

public class Person {
    protected String name;

    public String getName(){
        return "His name is unknown";
    }
}



