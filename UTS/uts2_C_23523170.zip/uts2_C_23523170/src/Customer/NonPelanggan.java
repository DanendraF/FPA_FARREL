package Customer;

/*23523170*/
public class NonPelanggan {
    public String Nama;
    public String Poin;
    public String Status;

    public String getNama() {
        return Nama;
    }

    public void setNama(String nama) {
        Nama = nama;
    }

    public String getPoin() {
        return Poin;
    }

    public void setPoin(String poin) {
        Poin = poin;
    }

    public String getStatus() {
        return Status;
    }
}


