package Menu;

/*23523170*/
class Makanan extends Menu {
    @Override
    public String getJenis() {
        return "Makanan";
    }
}
