package Menu;

public class Menu {
    
    public String Nama;
    public String Harga;
    public String Stok;
    public String Jenis;
    
    public String getNama() {
        return Nama;
    }

    public void setNama(String nama) {
        this.Nama = nama;
    }

    public String getHarga() {
        return Harga;
    }

    public void setHarga(String harga) {
        this.Harga = harga;
    }

    public String getStok() {
        return Stok;
    }

    public void setStok(String stok) {
        this.Stok = stok;
    }

    public String getJenis() {
        return Jenis;
    }

    public void setJenis(String jenis) {
        this.Jenis = jenis;
    }
}