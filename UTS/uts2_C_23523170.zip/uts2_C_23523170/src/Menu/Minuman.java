package Menu;

/*23523170*/
public class Minuman extends Menu {

    @Override
    public String getJenis() {
        return "Minuman";
    }

}